import sqlite3
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.utils.dates import days_ago
# from dags.support import inner
from plugins import tracking
import datetime


args = {
    'owner': 'airflow',
}



dag = DAG(
    dag_id='VA_tracking',
    default_args=args,
    schedule_interval=None,
    start_date=days_ago(2),
    tags=['track'],
)

start_operator = DummyOperator(task_id='ROBO_task', retries=3, dag=dag)

con = sqlite3.connect('/home/alex/PycharmProjects/office_camera/cameras2.sqlite3')
cursorObj = con.cursor()

cursorObj.execute('SELECT id FROM camera GROUP BY id')
cameras = cursorObj.fetchall()  # list tuple [(1,), (2,)]
con.close()


for num_cam in cameras:
    for hour in range(7,23):
        timeStart = datetime.time(hour, 0, 0)
        timeEnd = datetime.time(hour+1, 0, 0)
        task = PythonOperator(
            task_id='task_c{}_h{}'.format(num_cam[0], hour),
            python_callable=tracking.run_track,
            op_kwargs={'num_cam':num_cam[0], 'max_age':15, 'min_hits':1,
                       'data':datetime.datetime.now(),
                       'timeStart':timeStart,'timeEnd':timeEnd},
            dag=dag,
        )

        start_operator >> task

if __name__ == '__main__':
    pass
